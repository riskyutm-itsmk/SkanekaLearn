/*
  # Fix RLS policies for location_settings table

  1. Security Changes
    - Drop existing restrictive policies
    - Create new policies that work with our authentication system
    - Allow admins to manage locations
    - Allow teachers to read active locations

  2. Data
    - Insert default location after fixing policies
*/

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Admins can manage locations" ON public.location_settings;
DROP POLICY IF EXISTS "Teachers can read active locations" ON public.location_settings;

-- Create new policies that work with our custom authentication
CREATE POLICY "Admins can manage locations"
  ON public.location_settings
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.users 
      WHERE users.id = (
        SELECT id FROM public.users 
        WHERE email = current_setting('request.jwt.claims', true)::json->>'email'
        LIMIT 1
      )
      AND users.role = 'admin'
    )
  );

CREATE POLICY "Teachers can read active locations"
  ON public.location_settings
  FOR SELECT
  TO authenticated
  USING (
    is_active = true AND
    EXISTS (
      SELECT 1 FROM public.users 
      WHERE users.id = (
        SELECT id FROM public.users 
        WHERE email = current_setting('request.jwt.claims', true)::json->>'email'
        LIMIT 1
      )
      AND users.role IN ('guru', 'admin')
    )
  );

-- Temporarily disable RLS to insert default data
ALTER TABLE public.location_settings DISABLE ROW LEVEL SECURITY;

-- Insert default location
INSERT INTO public.location_settings (name, latitude, longitude, radius, is_active)
VALUES ('Sekolah Utama', -6.2088, 106.8456, 100, true)
ON CONFLICT DO NOTHING;

-- Re-enable RLS
ALTER TABLE public.location_settings ENABLE ROW LEVEL SECURITY;